# Close-loop-brain-states-automated-classification-and-regulation-system
## workflow for the real-time brain states analysis and control system
1 train the SS-ANN network with AccuSleep_train.m.

2 creat the Calibration Data file with AccuSleep GUI.

3 modify the parameters in realtime_automated_sleepmode_classify.m. 
